/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   help.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pruiz-ca <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/16 21:58:20 by pruiz-ca          #+#    #+#             */
/*   Updated: 2020/12/16 21:58:21 by pruiz-ca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HELP_H
# define HELP_H
# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>
# include <stdint.h>

typedef struct		s_map
{
	int				rows;
	int				cols;
	char			empt;
	char			obst;
	char			fill;
	int				**mtx;
	int				sq_size;
	int				min_i;
	int				min_j;
}					t_map;

int					ft_atoi(char *str);
int					check_first_line(t_map *map, int ifd);
int					get_line(t_map *map, int i, int ifd);
int					create_matrix(t_map *map, int ifd);
int					get_map_info(t_map *map, int ifd);
int					ft_strcmp(char *s1, char *s2);
void				free_map(t_map *map);
void				solve_mat(t_map *map);
void				*ft_strcpy(void *dest, void *src, size_t num);
void				solve_map(t_map *map);
void				*mod_malloc(void *ptr, size_t old_size, size_t new_size);
t_map				*create_map(char *file);
t_map				*map_error(void);

#endif
