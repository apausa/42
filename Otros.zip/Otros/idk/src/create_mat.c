/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   create_mat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pruiz-ca <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/14 14:32:21 by pruiz-ca          #+#    #+#             */
/*   Updated: 2020/12/16 22:01:53 by pruiz-ca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/help.h"

int		ft_min(int a, int b, int c)
{
	if (a <= b && a <= c)
		return (a);
	else if (b <= c && b <= a)
		return (b);
	else
		return (c);
}

void	solve_mat(t_map *map)
{
	int	r;
	int	c;

	r = map->rows - 1;
	while (r >= 0)
	{
		c = map->cols - 1;
		while (c >= 0)
		{
			if (map->mtx[r][c])
			{
				if (!(r == map->rows - 1 || c == map->cols - 1))
					map->mtx[r][c] = ft_min(map->mtx[r + 1][c + 1], \
							map->mtx[r + 1][c], map->mtx[r][c + 1]) + 1;
				if (map->mtx[r][c] >= map->sq_size)
				{
					map->sq_size = map->mtx[r][c];
					map->min_i = r;
					map->min_j = c;
				}
			}
			c--;
		}
		r--;
	}
}
