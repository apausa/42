/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_info.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ssanz-al <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/16 21:15:25 by ssanz-al          #+#    #+#             */
/*   Updated: 2020/12/16 21:15:26 by ssanz-al         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/help.h"

int	ft_isnumber(char *str)
{
	while (*str)
	{
		if (!(*str >= '0' && *str <= '9'))
			return (0);
		str++;
	}
	return (1);
}

int	get_map_info(t_map *map, int fd)
{
	char	c;
	char	rows[13];
	char	*prows;

	prows = rows;
	while (1)
	{
		if (read(fd, &c, 1) < 1 || (prows - rows == 13))
			return (1);
		if (c == '\n')
			break ;
		*prows++ = c;
	}
	if (prows - rows >= 4)
	{
		map->fill = *(prows - 1);
		map->obst = *(prows - 2);
		map->empt = *(prows - 3);
		*(prows - 3) = '\0';
	}
	else
		return (1);
	if (!ft_isnumber(rows) || map->empt == map->obst)
		return (1);
	return (!(map->rows = ft_atoi(rows)));
}
