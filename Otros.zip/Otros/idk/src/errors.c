/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   errors.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ssanz-al <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/16 21:14:39 by ssanz-al          #+#    #+#             */
/*   Updated: 2020/12/16 21:14:43 by ssanz-al         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/help.h"

void	nullify(t_map *map)
{
	int		i;

	i = 0;
	while (i < map->rows)
		map->mtx[i++] = NULL;
}

int		create_matrix(t_map *map, int fd)
{
	int		i;

	map->mtx = (int **)malloc(map->rows * sizeof(int *));
	nullify(map);
	if (check_first_line(map, fd))
		return (1);
	i = 1;
	while (i < map->rows)
	{
		map->mtx[i] = (int *)malloc(map->cols * sizeof(int));
		if (get_line(map, i, fd))
			return (1);
		i++;
	}
	if (read(fd, &i, 1))
		return (1);
	return (0);
}

int		check_first_line(t_map *map, int fd)
{
	char		c;
	int			i;
	int			ret;

	map->mtx[0] = (int *)malloc(128 * sizeof(int));
	map->cols = 13;
	i = 0;
	while (1)
	{
		ret = read(fd, &c, 1);
		if (c == '\n')
			break ;
		if ((c != map->empt && c != map->obst) || ret < 1)
			return (1);
		map->mtx[0][i++] = (c == map->empt) ? 1 : 0;
		if (i == map->cols)
		{
			map->mtx[0] = (int *)mod_malloc(map->mtx[0], \
	map->cols * sizeof(int), map->cols * 2 * sizeof(int));
			map->cols *= 2;
		}
	}
	map->mtx[0] = (int *)mod_malloc(map->mtx[0],
			map->cols * sizeof(int), i * sizeof(int));
	return (!(map->cols = i));
}

int		get_line(t_map *map, int i, int fd)
{
	int		j;
	int		ret;
	char	c;

	j = 0;
	while (1)
	{
		ret = read(fd, &c, 1);
		if (j == map->cols)
		{
			if (c != '\n')
				return (1);
			else
				return (0);
		}
		if ((c != map->empt && c != map->obst) || ret < 1)
			return (1);
		map->mtx[i][j++] = (c == map->empt) ? 1 : 0;
	}
	return (1);
}
