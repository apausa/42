/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   helper_functions.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ssanz-al <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/16 21:14:52 by ssanz-al          #+#    #+#             */
/*   Updated: 2020/12/16 21:14:54 by ssanz-al         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/help.h"

int		ft_atoi(char *str)
{
	int	nb;
	int	i;

	nb = 0;
	i = 0;
	while (str[i])
	{
		if (str[i] < '0' || str[i] > '9')
			return (-1);
		i++;
	}
	if (i == 0)
		return (-1);
	i = 0;
	while (str[i])
	{
		nb *= 10;
		nb += str[i++] - '0';
	}
	return (nb);
}

int		ft_strcmp(char *s1, char *s2)
{
	while (*s1 == *s2 && *s1)
	{
		s1++;
		s2++;
	}
	return (*s1 - *s2);
}

void	*mod_malloc(void *ptr, size_t old_size, size_t new_size)
{
	void	*tmp;

	tmp = malloc(new_size);
	ft_strcpy(tmp, ptr, (old_size < new_size) ? old_size : new_size);
	free(ptr);
	return (tmp);
}

void	*ft_strcpy(void *dest, void *src, size_t num)
{
	unsigned char	*pdest;
	unsigned char	*psrc;

	pdest = (unsigned char *)dest;
	psrc = (unsigned char *)src;
	while (num--)
		*pdest++ = *psrc++;
	return (dest);
}
