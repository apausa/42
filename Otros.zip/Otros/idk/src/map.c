/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pruiz-ca <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/16 21:15:09 by ssanz-al          #+#    #+#             */
/*   Updated: 2020/12/16 21:58:35 by pruiz-ca         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/help.h"

void	free_map(t_map *map)
{
	int		i;

	i = 0;
	while (i < map->rows)
		if (map->mtx[i])
			free(map->mtx[i++]);
		else
			break ;
	free(map->mtx);
	free(map);
}

t_map	*create_map(char *file)
{
	t_map	*map;
	int		fd;

	if (!ft_strcmp(file, "stdin"))
		fd = STDIN_FILENO;
	else
		fd = open(file, O_RDONLY);
	if (fd == -1)
		return (map_error());
	map = (t_map *)malloc(sizeof(t_map));
	if (get_map_info(map, fd))
	{
		free(map);
		return (map_error());
	}
	if (create_matrix(map, fd))
	{
		free_map(map);
		return (map_error());
	}
	close(fd);
	map->sq_size = 0;
	return (map);
}
