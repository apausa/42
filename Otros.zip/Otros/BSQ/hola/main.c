/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: papausa- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/16 15:47:21 by papausa-          #+#    #+#             */
/*   Updated: 2020/12/16 15:47:41 by papausa-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	**ft_primero (int a, char *b, char **argv)
{
	char 	**c;
	int		d;

	while (argv[1][a] != '\0')
	{
		 while (argv[1][a] != ' ')
		 {
			 c[d][a] = argv[1][a];
			 a++; 
		 }
		d++
		a++;
	}
	return (c);
}

int main(int argc, char **argv)
{
	int a;
	char b[];
	int start;

	a = 0;
	if (argc != 2)
		return (0);
	while (argv[1][a] != ' ')
		a++;
	if (a != 4)
		return (0);
	b[0] = argv[1][a - 4]; //Tamaño.
	b[1] = argv[1][a - 3]; //Vacío.
	b[2] = argv[1][a - 2]; //Obstáculo.
	b[3] = argv[1][a - 1]; //Lleno.
	if ((b[1] != b[2]) || (b[2] != b[3]) || (b[1] != b[3]))
		return (0);
	a++;
	ft_primero(a, b, argv)
}