
int        ft_indraw(char *buff, char *keys, int dim)
{
	int i;
	int start;

	//nos colocmos en posicion del primer salo de linea
	i = 0;
	while (buff[i] != '\n')
		i++;
	//incluimos los 3 char de antes que representan a : vacio, obstaculo y lleno
	keys[0] = buff[i - 3];
	keys[1] = buff[i - 2];
	keys[2] = buff[i - 1];
	//comprobamos que no coincidan caracteres
	if (keys[0] == keys[1] || keys[0] == keys[2] || keys[1] == keys[2])
		return (0);
	//incluimos la posicion donde vamos a empezar a leer el mapa. e.d: donde empieza el mapa y saltandose la linea de info
	start = i + 1;
	//comprobamos el numero de lineas que aparece en la info y lo guardamos.
	i = 0;
	dim = 0;
	while (i != keys[0])
	{
		if(buff[i] >= '0' && buff[i] <= '9')
			dim = (dim * 10) + (int)(buff[i] - '0');
		i++;
	}
	//control de errores: si no se encuentra ningun numero en la info dim[1] = 0
	if (dim == 0)
		return (0);
	else
		return (start);
}