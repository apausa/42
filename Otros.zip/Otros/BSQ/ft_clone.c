/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_clone.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dagarcia <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/14 19:33:20 by dagarcia          #+#    #+#             */
/*   Updated: 2020/12/15 17:41:28 by dagarcia         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		**ft_clone(int **src, int x, int y)
{
	int		**dest;
	int		i;
	int		j;

	i = 0;
	j = 0;
	dest = (int **)malloc(sizeof(int *) * y);
	while (i < x)
	{
		dest[i] = (int *)malloc(sizeof(int) * x);
		i++;
	}
	i = 0;
	while (i < x)
	{
		dest[j][i] = src[j][i];
		j++;
		if (j == y)
		{
			i++;
			j = 0;
		}
	}
	return (dest);
}
