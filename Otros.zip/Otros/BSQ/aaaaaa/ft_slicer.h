/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_slicer.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bboriko- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/13 22:30:42 by bboriko-          #+#    #+#             */
/*   Updated: 2020/12/13 22:30:44 by bboriko-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_SLICER_H
# define FT_SLICER_H

char	**ft_tab(int *ar, char **tab, char *argv);
int		ft_zero_adder(char **tab, char *argv);
int		ft_strlen(char *argv);

#endif
