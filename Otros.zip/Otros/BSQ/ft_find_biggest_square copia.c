/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_biggest_square.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cmarcu <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/14 18:33:56 by cmarcu            #+#    #+#             */
/*   Updated: 2020/12/16 11:35:35 by cmarcu           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int ft_get_min(int j, int k, int n)
{
	int min;

	if (j <= k)
	{
		min = j;
	}
	else
	{
		min = k;
	}
	if (min <= n)
	{
		return (min);
	}
	else
	{
		return (n);
	}
}

int *ft_find_biggest_sq(int **arr, int *dim)
{
	int i;
	int j;
	int result[3] = {0, 0, 0};

	i = 0;
	j = 0;
	while (i < dim[0])
	{
		while (j < dim[1])
		{
			if (i == 0 || j == 0)
				continue ;
			else if (arr[i][j] > 0)
			{
				arr[i][j] = 1 + ft_get_min(arr[i][j - 1], arr[i - 1][j], arr[i - 1][j - 1]);
				if (arr[i][j] > square_size)
				{
					result[0] = arr[i][j];
					result[1] = j;
					result[2] = i;
				}
			}
			j++;
		}
		i++;
	}
	return (result);
}
