/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solve_map.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rorozco- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/16 18:54:41 by rorozco-          #+#    #+#             */
/*   Updated: 2020/12/16 18:54:46 by rorozco-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/help.h"
#include <stdio.h>

void	print_map(t_map *map, int min_i, int min_j)
{
	int	max_i;
	int	max_j;
	int	i;
	int	j;

	max_i = min_i + map->sq_size - 1;
	max_j = min_j + map->sq_size - 1;
	i = 0;
	while (i < map->rows)
	{
		j = 0;
		while (j < map->cols)
		{
			if (!(map->mtx[i][j]))
				write(1, &(map->obst), 1);
			else if (i >= min_i && i <= max_i && \
					j >= min_j && j <= max_j)
				write(1, &(map->fill), 1);
			else
				write(1, &(map->empt), 1);
			j++;
		}
		write(1, "\n", 1);
		i++;
	}
}

void	solve_map(t_map *map)
{
	int			min_i;
	int			min_j;

	solve_mat(map);
	min_i = map->min_i;
	min_j = map->min_j;
	print_map(map, min_i, min_j);
	free_map(map);
}
