/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rorozco- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/16 18:54:12 by rorozco-          #+#    #+#             */
/*   Updated: 2020/12/16 18:54:14 by rorozco-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/help.h"

int	main(int argc, char **av)
{
	t_map		*map;
	int			i;

	if (argc < 2)
	{
		map = create_map("stdin");
		if (map)
			solve_map(map);
		return (0);
	}
	i = 1;
	while (i < argc)
	{
		map = create_map(av[i]);
		if (map)
			solve_map(map);
		i++;
		if (i < argc)
			write(1, "\n", 1);
	}
	return (0);
}
